Pal-Online identity kit, direction Midmak.
Fonts: Hepta Slab (Mint Type) and Mona Sans (GitHub), SIL Open Font License 1.1, free from Google Fonts.
The shekel sign in Hepta Slab was drawn for this identity and ships in the site font files.
Colours: mortar #F3F4F1, block #D9DBD6, charcoal #141618, line #FF4F12, oxide #983812, night block #272B2E.
